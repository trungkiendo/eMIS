from django.apps import AppConfig


class WineConfig(AppConfig):
    name = 'wine'
