import tkinter as tk
from tkinter import ttk
from login import LoginScreen


class DatamartScreen:
    def __init__(self, parent):
        self.parent = parent
        self.parent.title("Datamart Screen")
        self.parent.geometry("400x300")
        self.current_screen = None

        self.notebook = ttk.Notebook(self.parent)

        self.datamart_tab = tk.Frame(self.notebook)
        self.scheduler_tab = tk.Frame(self.notebook)
        self.resource_tab = tk.Frame(self.notebook)

        self.notebook.add(self.datamart_tab, text="Datamart")
        self.notebook.add(self.scheduler_tab, text="Scheduler")
        self.notebook.add(self.resource_tab, text="Resource")

        self.notebook.pack(expand=1, fill="both")
        self.notebook.select(self.datamart_tab)

        # Add back button to return to home screen
        back_button = tk.Button(self.parent, text="Back", command=self.show_home_screen)
        back_button.pack()

        # Update current screen
        self.current_screen = self.parent

    def show_home_screen(self):
        # Check if there is a current screen and withdraw it
        if self.current_screen:
            self.current_screen.withdraw()

        # Create login screen and show it
        self.home_screen = tk.Toplevel(self.parent)
        login = LoginScreen(self.home_screen)
        self.home_screen.mainloop()

        # Update current screen
        self.current_screen = self.home_screen