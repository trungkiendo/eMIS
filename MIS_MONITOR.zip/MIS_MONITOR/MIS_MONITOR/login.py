import tkinter as tk
import sqlite3
from database import UserDatabase


class LoginScreen:
    def __init__(self, parent, user_database):
        self.parent = parent
        self.parent.title("Login Screen")
        self.parent.geometry("300x200")
        self.current_screen = None
        self.login_screen = parent
        self.user_database = user_database

        # Create entry fields for username and password
        self.username_label = tk.Label(self.parent, text="Username:")
        self.username_entry = tk.Entry(self.parent)
        self.password_label = tk.Label(self.parent, text="Password:")
        self.password_entry = tk.Entry(self.parent, show="*")

        # Create login button
        self.login_button = tk.Button(self.parent, text="Login", command=self.login)

        # Position widgets using grid layout
        self.username_label.grid(row=0, column=0)
        self.username_entry.grid(row=0, column=1)
        self.password_label.grid(row=1, column=0)
        self.password_entry.grid(row=1, column=1)
        self.login_button.grid(row=2, column=1)

    def login(self):
        # Check if username and password are valid
        username = self.username_entry.get()
        password = self.password_entry.get()
        if self.user_database.authenticate(username, password):
            self.show_home_screen()
        else:
            self.show_error("Invalid username or password.")

    def show_home_screen(self):
        # Check if there is a current screen and withdraw it
        if self.current_screen:
            self.current_screen.withdraw()

        # Create home screen with options to go to datamart or report pages and a logout button
        self.home_screen = tk.Toplevel(self.parent)
        self.home_screen.title("Home Screen")
        self.home_screen.geometry("300x200")

        datamart_button = tk.Button(self.home_screen, text="Datamart", command=self.show_datamart_screen)
        report_button = tk.Button(self.home_screen, text="Report", command=self.show_report_screen)
        logout_button = tk.Button(self.home_screen, text="Logout", command=self.home_screen.destroy)

        datamart_button.pack()
        report_button.pack()
        logout_button.pack()

        # Update current screen
        self.current_screen = self.home_screen

        # Hide the login screen
        self.login_screen.withdraw()

    def show_error(self, message):
        # Create error message box
        error_box = tk.Toplevel(self.parent)
        error_box.title("Error")
        error_label = tk.Label(error_box, text=message)
        error_label.pack()
        ok_button = tk.Button(error_box, text="OK", command=error_box.destroy)
        ok_button.pack()


if __name__ == '__main__':
    root = tk.Tk()
    user_database = UserDatabase()
    login = LoginScreen(root, user_database)
    root.mainloop()