import tkinter as tk
from login_screen import LoginScreen
from datamart_screen import DatamartScreen
from report_screen import ReportScreen

if __name__ == '__main__':
    root = tk.Tk()
    login = LoginScreen(root)

    def show_datamart_screen():
        datamart = DatamartScreen(root, login.show_home_screen)

    def show_report_screen():
        report = ReportScreen(root, login.show_home_screen)

    login.show_datamart_screen = show_datamart_screen
    login.show_report_screen = show_report_screen

    root.mainloop()