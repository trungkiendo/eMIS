import tkinter as tk
from tkinter import ttk
import sqlite3


class LoginScreen:
    def __init__(self, parent):
        self.parent = parent
        self.parent.title("Login Screen")
        self.parent.geometry("300x200")
        self.current_screen = None
        self.login_screen = parent

        # Create entry fields for username and password
        self.username_label = tk.Label(self.parent, text="Username:")
        self.username_entry = tk.Entry(self.parent)
        self.password_label = tk.Label(self.parent, text="Password:")
        self.password_entry = tk.Entry(self.parent, show="*")

        # Create login button
        self.login_button = tk.Button(self.parent, text="Login", command=self.login)

        # Position widgets using grid layout
        self.username_label.grid(row=0, column=0)
        self.username_entry.grid(row=0, column=1)
        self.password_label.grid(row=1, column=0)
        self.password_entry.grid(row=1, column=1)
        self.login_button.grid(row=2, column=1)

        # Create database and insert sample user
        self.conn = sqlite3.connect("users.db")
        self.c = self.conn.cursor()
        self.c.execute("CREATE TABLE IF NOT EXISTS users (username TEXT, password TEXT)")
        self.c.execute("INSERT INTO users VALUES (?, ?)", ("admin", "a"))
        self.conn.commit()

    def login(self):
        # Check if username and password are valid
        username = self.username_entry.get()
        password = self.password_entry.get()
        self.c.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
        result = self.c.fetchone()
        if result:
            self.show_home_screen()
        else:
            self.show_error("Invalid username or password.")

    def show_home_screen(self):
        # Check if there is a current screen and withdraw it
        if self.current_screen:
            self.current_screen.withdraw()

        # Create home screen with options to go to datamart or report pages and a logout button
        self.home_screen = tk.Toplevel(self.parent)
        self.home_screen.title("Home Screen")
        self.home_screen.geometry("300x200")

        datamart_button = tk.Button(self.home_screen, text="Datamart", command=self.show_datamart_screen)
        report_button = tk.Button(self.home_screen, text="Report", command=self.show_report_screen)
        logout_button = tk.Button(self.home_screen, text="Logout", command=self.home_screen.destroy)

        datamart_button.pack()
        report_button.pack()
        logout_button.pack()

        # Update current screen
        self.current_screen = self.home_screen

        # Hide the login screen
        self.login_screen.withdraw()

    def show_datamart_screen(self):
        # Check if there is a current screen and withdraw it
        if self.current_screen:
            self.current_screen.withdraw()

        # Create datamart screen with tabs for datamart, scheduler, and resource pages
        datamart_screen = tk.Toplevel(self.parent)
        datamart_screen.title("Datamart Screen")
        datamart_screen.geometry("400x300")

        self.notebook = ttk.Notebook(datamart_screen)

        self.datamart_tab = tk.Frame(self.notebook)
        self.scheduler_tab = tk.Frame(self.notebook)
        self.resource_tab = tk.Frame(self.notebook)

        self.notebook.add(self.datamart_tab, text="Datamart")
        self.notebook.add(self.scheduler_tab, text="Scheduler")
        self.notebook.add(self.resource_tab, text="Resource")

        self.notebook.pack(expand=1, fill="both")
        self.notebook.select(self.datamart_tab)

        # Add back button to return to home screen
        back_button = tk.Button(datamart_screen, text="Back", command=self.show_home_screen)
        back_button.pack()

        # Update current screen
        self.current_screen = datamart_screen

    def show_report_screen(self):
        # Check if there is a current screen and withdraw it
        if self.current_screen:
            self.current_screen.withdraw()

        # Create report screen with tabs for report, scheduler, and datasource pages
        report_screen = tk.Toplevel(self.parent)
        report_screen.title("Report Screen")
        report_screen.geometry("400x300")

        self.notebook = ttk.Notebook(report_screen)

        self.report_tab = tk.Frame(self.notebook)
        self.scheduler_tab = tk.Frame(self.notebook)
        self.datasource_tab = tk.Frame(self.notebook)

        self.notebook.add(self.report_tab, text="Report")
        self.notebook.add(self.scheduler_tab,text="Scheduler")
        self.notebook.add(self.datasource_tab, text="Datasource")

        self.notebook.pack(expand=1, fill="both")
        self.notebook.select(self.report_tab)

        # Add back button to return to home screen
        back_button = tk.Button(report_screen, text="Back", command=self.show_home_screen)
        back_button.pack()

        # Update current screen
        self.current_screen = report_screen

    def show_error(self, message):
        # Create error message box
        error_box = tk.Toplevel(self.parent)
        error_box.title("Error")
        error_label = tk.Label(error_box, text=message)
        error_label.pack()
        ok_button = tk.Button(error_box, text="OK", command=error_box.destroy)
        ok_button.pack()

    def generate_report(self):
        # TODO: Implement method to generate report
        pass


if __name__ == '__main__':
    root = tk.Tk()
    login = LoginScreen(root)
    root.mainloop()