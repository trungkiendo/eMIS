import tkinter as tk
from tkinter import ttk

class ReportScreen:
    def __init__(self, parent, show_home_screen):
        self.parent = parent
        self.show_home_screen = show_home_screen

        # Create report screen with tabs for report, scheduler, and datasource pages
        report_screen = tk.Toplevel(self.parent)
        report_screen.title("Report Screen")
        report_screen.geometry("400x300")

        self.notebook = ttk.Notebook(report_screen)

        self.report_tab = tk.Frame(self.notebook)
        self.scheduler_tab = tk.Frame(self.notebook)
        self.datasource_tab = tk.Frame(self.notebook)

        self.notebook.add(self.report_tab, text="Report")
        self.notebook.add(self.scheduler_tab,text="Scheduler")
        self.notebook.add(self.datasource_tab, text="Datasource")

        self.notebook.pack(expand=1, fill="both")
        self.notebook.select(self.report_tab)

        # Add back button to return to home screen
        back_button = tk.Button(report_screen, text="Back", command=self.hide)
        back_button.pack()

        # Update current screen
        self.current_screen = report_screen

    def hide(self):
        self.current_screen.withdraw()
        self.show_home_screen()