import sqlite3


class UserDatabase:
    def __init__(self):
        self.conn = sqlite3.connect('users.db')
        self.c = self.conn.cursor()
        self.c.execute('''CREATE TABLE IF NOT EXISTS users (username text, password text)''')
        self.conn.commit()

    def add_user(self, username, password):
        self.c.execute('''INSERT INTO users (username, password) VALUES (?, ?)''', (username, password))
        self.conn.commit()

    def authenticate(self, username, password):
        self.c.execute('''SELECT * FROM users WHERE username=? AND password=?''', (username, password))
        return self.c.fetchone() is not None