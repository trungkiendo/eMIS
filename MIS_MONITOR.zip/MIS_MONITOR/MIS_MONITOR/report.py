import tkinter as tk
from tkinter import ttk
from login import LoginScreen


class ReportScreen:
    def __init__(self, parent):
        self.parent = parent
        self.parent.title("Report Screen")
        self.parent.geometry("400x300")
        self.current_screen = None

        self.notebook = ttk.Notebook(self.parent)

        self.report_tab = tk.Frame(self.notebook)
        self.scheduler_tab = tk.Frame(self.notebook)
        self.datasource_tab = tk.Frame(self.notebook)

        self.notebook.add(self.report_tab, text="Report")
        self.notebook.add(self.scheduler_tab, text="Scheduler")
        self.notebook.add(self.datasource_tab, text="Datasource")

        self.notebook.pack(expand=1, fill="both")
        self.notebook.select(self.report_tab)

        # Add back button to return to home screen
        back_button = tk.Button(self.parent, text="Back", command=self.show_home_screen)
        back_button.pack()

        # Update current screen
        self.current_screen = self.parent

    def show_home_screen(self):
        # Check if there is a current screen and withdraw it
        if self.current_screen:
            self.current_screen.withdraw()

        # Create login screen and show it
        self.home_screen = tk.Toplevel(self.parent)
        login = LoginScreen(self.home_screen)
        self.home_screen.mainloop()

        # Update current screen
        self.current_screen = self.home_screen


if __name__ == '__main__':
    root = tk.Tk()
    report = ReportScreen(root)
    root.mainloop()