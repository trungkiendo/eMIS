
import pandas as pd
import sqlite3

# Read data from Excel file
df = pd.read_excel('D:\Kien\Python\MIS_MONITOR\Input\LOG_SCHEDULER_DATAMART.xlsx', sheet_name=2)
# df = pd.read_excel('D:\Kien\Datamart\Input\SCHEDULER_DATAMART.xlsx', sheet_name=0)
# df = pd.read_excel('D:\Kien\Datamart\Input\MIS_LOG_DATASOURCE_DAILY.xlsx', sheet_name=0)
# df = pd.read_excel('D:\Kien\Datamart\Input\MIS_LOG_DATAMART.xlsx', sheet_name=0)


# Get column names and data types
column_names = df.columns.tolist()
column_types = df.dtypes.tolist()

# Create a new SQLite database
conn = sqlite3.connect('mis.db')

# Drop the table if it already exists
table_name = 'dm_datamart'
drop_table_query = 'DROP TABLE IF EXISTS ' + table_name
conn.execute(drop_table_query)

# Create a new table
create_table_query = 'CREATE TABLE ' + table_name + '('
for i in range(len(column_names)):
    if column_names[i] == 'Field Name':  # Handle the column 'Field Name'
        create_table_query += 'Field_Name TEXT'
    elif column_types[i].name == 'object':  # Handle string columns
        create_table_query += column_names[i] + ' TEXT'
    else:  # Handle other columns
        create_table_query += column_names[i] + ' ' + column_types[i].name
    if i < len(column_names) - 1:
        create_table_query += ', '
create_table_query += ')'
print(create_table_query)
# conn.execute(create_table_query)
# Add data to the table
df.to_sql(table_name, conn, if_exists='append', index=False)

# Close the connection
conn.close()


# Kết nối tới database
conn = sqlite3.connect('mis.db')

# Đọc dữ liệu từ bảng vào DataFrame
df1 = pd.read_sql_query("SELECT * from dm_datamart", conn)

# In ra DataFrame
print(df1)
