# import pandas as pd
# import sqlite3
#
# # df1 = pd.read_excel('D:\Kien\Python\MIS_MONITOR\Input\LOG_SCHEDULER_DATAMART.xlsx', sheet_name=0)
# # df2 = pd.read_excel('D:\Kien\Python\MIS_MONITOR\Input\LOG_SCHEDULER_DATAMART.xlsx', sheet_name=1)
# # df3 = pd.read_excel('D:\Kien\Python\MIS_MONITOR\Input\LOG_SCHEDULER_DATAMART.xlsx', sheet_name=2)
# # Read data from Excel file
# df1 = pd.read_excel('D:\Kien\Datamart\Input\SCHEDULER_DATAMART.xlsx', sheet_name=0)
# df2 = pd.read_excel('D:\Kien\Datamart\Input\MIS_LOG_DATASOURCE_DAILY.xlsx', sheet_name=0)
# df3 = pd.read_excel('D:\Kien\Datamart\Input\MIS_LOG_DATAMART.xlsx', sheet_name=0)
#
# # kết nối với cơ sở dữ liệu SQLite
# conn = sqlite3.connect('MIS.db')
#
# # tạo đối tượng cursor
# cursor = conn.cursor()
#
# # cập nhật bảng table1 từ khung dữ liệu dataframe1
# df1.to_sql('dm_scheduler', conn, if_exists='replace', index=False)
# df2.to_sql('dm_datasource', conn, if_exists='replace', index=False)
# df3.to_sql('dm_datamart', conn, if_exists='replace', index=False)
# # đóng kết nối với cơ sở dữ liệu SQLite
# conn.close()
import os
import glob
import openpyxl
import sqlite3
fol_der = "V:\LOG DATAMART"
lasest_file = max(glob.glob(os.path.join(fol_der,"*.xlsx")),key=os.path.getmtime)
lasest_file = lasest_file.replace("~$","")
if lasest_file is not None:
    workbook = openpyxl.load_workbook(filename=lasest_file)
    worksheet = workbook.get_sheet_names("scheduler")
    for raw in worksheet.iter_rows(values_only=True):
        print(raw)
    print(lasest_file)
else:
    print('Note')

# # Open the Excel file
# workbook1 = openpyxl.load_workbook('D:\Kien\Datamart\Input\SCHEDULER_DATAMART.xlsx')
# workbook2 = openpyxl.load_workbook('D:\Kien\Datamart\Input\MIS_LOG_DATASOURCE_DAILY.xlsx')
# workbook3 = openpyxl.load_workbook('D:\Kien\Datamart\Input\MIS_LOG_DATAMART.xlsx')
# # Open the Excel file
# workbook1 = openpyxl.load_workbook('D:\Kien\Datamart\Input\SCHEDULER_DATAMART.xlsx')
# workbook2 = openpyxl.load_workbook('D:\Kien\Datamart\Input\MIS_LOG_DATASOURCE_DAILY.xlsx')
# workbook3 = openpyxl.load_workbook('D:\Kien\Datamart\Input\MIS_LOG_DATAMART.xlsx')
#
# Select the worksheet
worksheet1 = workbook.get_sheet_names("scheduler")
worksheet2 = workbook.get_sheet_names("datasource")
worksheet3 = workbook.get_sheet_names("datamart")
#
# Connect to the SQLite database
conn = sqlite3.connect('MIS.db')

# Iterate over the rows in the worksheet and insert the data into the database
for row in worksheet3.iter_rows(values_only=True):
    cursor = conn.cursor()
    cursor.execute("delete from dm_datamart")
    cursor.execute("INSERT INTO dm_datamart (Id,Tb_No, Datamart, Table_Name, Old_Runtime, Start_Runtime, End_Runtime, Rownum, Status, Desc) "
                   "VALUES ( ?,?, ?, ?, ?, ?, ?, ?, ?, ?)", row)
    conn.commit()

for row in worksheet1.iter_rows(values_only=True):
    cursor = conn.cursor()
    cursor.execute("delete from dm_scheduler")
    cursor.execute("INSERT INTO dm_scheduler (Code, Datamart, Code_SAS, Groups, Status, Time_check, RunYN, Run_time, Time_Finish, Desc) "
                   "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", row)
    conn.commit()

for row in worksheet3.iter_rows(values_only=True):
    cursor = conn.cursor()
    cursor.execute("delete from dm_datasource")
    cursor.execute("INSERT INTO dm_datasource (Code, Datamart, libname, tabname, DailyYN, crdate, crtime, FileSize, RunYN, Desc) "
                   "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", row)

# Close the database connection
conn.close()

