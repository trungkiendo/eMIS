from .menu import Menu, MenuItem

__version__ = '1.2.1'
__url__ = 'https://github.com/borgstrom/django-simple-menu'
