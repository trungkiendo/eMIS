Example Project
===============

If you're looking for a quick way to evaluate django-simple-menu there's an
`example project`_ located in the github source repository that can be
quickly setup to learn and tinker with the menu system. Simply clone the
github repo to your local development workspace and then follow the README
file located in the "example" folder of the sources.

.. _example project: https://github.com/fatbox/django-simple-menu/tree/master/example/
